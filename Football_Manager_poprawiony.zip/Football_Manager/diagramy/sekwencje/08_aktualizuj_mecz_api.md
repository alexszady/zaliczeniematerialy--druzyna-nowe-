# Diagram sekwencji — 08 aktualizuj mecz api

```mermaid
sequenceDiagram
    actor C as Klient REST API
    participant API as Express API
    participant DB as SQLite
    C->>API: PUT /api/matches/:id (JSON)
    API->>DB: UPDATE matches SET ... WHERE id = ?
    DB-->>API: Status zapytania SQL
    API-->>C: 200 OK + komunikat
    Note over C,API: Endpoint istnieje, ale interfejs WWW nie udostępnia edycji meczu.
```
