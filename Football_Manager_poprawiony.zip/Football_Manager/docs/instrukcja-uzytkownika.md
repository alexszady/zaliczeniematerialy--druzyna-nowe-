# Instrukcja użytkownika — Football Manager

## 1. Uruchomienie

1. Zainstaluj Node.js 18 lub nowszy oraz npm.
2. Otwórz terminal w katalogu z `package.json`.
3. Wykonaj `npm install`.
4. Wykonaj `npm start`.
5. Otwórz `http://localhost:3000`.

## 2. Dashboard

Dashboard prezentuje liczbę zawodników, sumę goli, sumę asyst i liczbę zapisanych meczów.

## 3. Zawodnicy

W sekcji „Zawodnicy” można przeglądać listę oraz dodać zawodnika. Formularz wymaga imienia i nazwiska, numeru oraz pozycji. Statystyki goli, asyst i występów mają wartości początkowe 0. Przycisk „Usuń” usuwa wskazany rekord po potwierdzeniu.

## 4. Terminarz

Sekcja „Terminarz” prezentuje zapisane spotkania. Można dodać mecz, podając obowiązkowo przeciwnika i datę. Godzina, miejsce i wynik są polami dodatkowymi. Mecz można usunąć po potwierdzeniu.

## 5. Tabela strzelców

Sekcja „Strzelcy” prezentuje ranking zawodników posortowany malejąco według liczby goli.

## 6. Ograniczenia

Interfejs WWW nie udostępnia edycji istniejących zawodników ani meczów, mimo że backend ma odpowiednie endpointy PUT. System nie posiada kont użytkowników ani ról.

## 7. Zakończenie pracy

Zatrzymaj serwer w terminalu skrótem `CTRL + C`.
