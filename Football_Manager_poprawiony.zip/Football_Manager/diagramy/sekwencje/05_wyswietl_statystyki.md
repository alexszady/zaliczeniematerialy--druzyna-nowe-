# Diagram sekwencji — wyświetlenie statystyk

```mermaid
sequenceDiagram
    actor U as Użytkownik
    participant UI as Interfejs WWW
    participant API as Express API
    participant DB as SQLite
    U->>UI: Uruchamia aplikację
    UI->>API: GET /api/players
    API->>DB: SELECT * FROM players
    DB-->>API: Rekordy zawodników
    API-->>UI: JSON zawodników
    UI->>API: GET /api/matches
    API->>DB: SELECT * FROM matches ORDER BY match_date ASC
    DB-->>API: Rekordy meczów
    API-->>UI: JSON meczów
    UI->>UI: Sumuje gole i asysty oraz liczy rekordy
    UI-->>U: Dashboard prezentuje statystyki
```
