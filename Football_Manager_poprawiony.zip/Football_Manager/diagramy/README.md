# Diagramy projektu

Diagramy PNG/SVG znajdują się w `png/`, ich źródła Graphviz w `zrodla_dot/`, a diagramy sekwencji Mermaid w `sekwencje/`.

Diagramy aktywności: po jednym dla każdego z dziesięciu opisanych przypadków użycia. Diagramy sekwencji opisują ścieżkę poprawnego wykonania.
