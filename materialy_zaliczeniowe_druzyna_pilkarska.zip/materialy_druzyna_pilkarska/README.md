# Materiały zaliczeniowe — System zarządzania drużyną piłkarską

Materiały przygotowano na podstawie przesłanego repozytorium `alexszady-druzyna` oraz struktury diagramów widocznych w repozytorium materiałów zaliczeniowych.

## Zawartość
- `docs/aktorzy.md` — aktorzy i ich uprawnienia.
- `docs/wymagania.md` — wymagania funkcjonalne i niefunkcjonalne.
- `docs/przypadki-uzycia/` — siedem opisów przypadków użycia.
- `diagramy/png/` — gotowe diagramy PNG.
- `diagramy/zrodla_dot/` — edytowalne źródła Graphviz dla każdego PNG.
- `diagramy/opis-diagramow.md` — opis i zakres diagramów.

## Diagramy
1. Podstawowy diagram przypadków użycia.
2. Rozszerzony diagram przypadków użycia.
3. ERD bazy danych.
4. Diagram klas.
5–9. Diagramy aktywności: wyświetlanie zawodników, dodawanie, edycja, usuwanie zawodnika i zarządzanie meczami.
10–14. Diagramy sekwencji dla tych samych głównych procesów.

## Ważne uwagi dotyczące zgodności z kodem
Model danych odzwierciedla tabele `players` i `matches` tworzone w `server.js`. W aktualnej implementacji tabele nie mają relacji kluczem obcym. Interfejs zawiera usuwanie zawodników i meczów; backend udostępnia CRUD zawodników i endpointy meczów. Diagramy opisują obecny zakres projektu, a nie funkcje, których nie potwierdzono w kodzie.

## Uruchomienie aplikacji
W katalogu projektu:
```bash
npm install
npm start
```
Serwer domyślnie nasłuchuje na porcie 3000.
