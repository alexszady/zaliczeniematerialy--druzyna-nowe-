# Diagram sekwencji — 03 aktualizuj zawodnika api

```mermaid
sequenceDiagram
    actor C as Klient REST API
    participant API as Express API
    participant DB as SQLite
    C->>API: PUT /api/players/:id (JSON)
    API->>DB: UPDATE players SET ... WHERE id = ?
    DB-->>API: Status zapytania SQL
    API-->>C: 200 OK + komunikat
    Note over C,API: Endpoint istnieje, ale interfejs WWW nie udostępnia edycji zawodnika.
```
