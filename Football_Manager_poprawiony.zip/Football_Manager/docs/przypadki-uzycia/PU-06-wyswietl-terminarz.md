# Wyświetl terminarz

- **ID:** PU_06
- **Aktor:** Użytkownik aplikacji
- **Warunki wstępne:** Aplikacja została uruchomiona.

## Scenariusz podstawowy
1. Użytkownik wybiera sekcję „Terminarz”.
2. Interfejs wysyła `GET /api/matches`.
3. API pobiera mecze z SQLite, sortując je rosnąco według daty.
4. Interfejs wyświetla przeciwnika, datę, godzinę, miejsce i wynik.

## Scenariusze alternatywne / błędy
Jeśli tabela nie zawiera rekordów, wyświetlany jest komunikat „Brak meczów w terminarzu”.

## Warunek końcowy
Terminarz zostaje wyświetlony.
