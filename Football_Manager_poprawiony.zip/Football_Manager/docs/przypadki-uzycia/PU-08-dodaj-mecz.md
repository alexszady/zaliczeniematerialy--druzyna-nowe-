# Dodaj mecz

- **ID:** PU_08
- **Aktor:** Użytkownik aplikacji
- **Warunki wstępne:** Użytkownik otworzył sekcję „Terminarz”.

## Scenariusz podstawowy
1. Użytkownik otwiera formularz dodawania meczu.
2. Wprowadza przeciwnika i datę; może podać godzinę, miejsce i wynik.
3. Interfejs sprawdza obecność przeciwnika i daty.
4. Interfejs wysyła `POST /api/matches` z danymi JSON.
5. API waliduje wymagane pola i zapisuje mecz w SQLite.
6. Interfejs odświeża terminarz.

## Scenariusze alternatywne / błędy
Brak przeciwnika lub daty powoduje komunikat walidacyjny. API zwraca HTTP 400, jeśli wymagane dane nie zostały przesłane.

## Warunek końcowy
Mecz zostaje zapisany w tabeli `matches` i pojawia się w terminarzu.
