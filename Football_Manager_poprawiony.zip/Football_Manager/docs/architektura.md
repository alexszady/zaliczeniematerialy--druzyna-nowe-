# Dokumentacja techniczna systemu Football Manager

## 1. Architektura

Aplikacja działa w architekturze klient–serwer. Przeglądarka wyświetla interfejs, serwer Express udostępnia REST API, a SQLite przechowuje dane w lokalnym pliku `database.db`.

## 2. Frontend

- `public/index.html` — struktura czterech sekcji: Dashboard, Zawodnicy, Terminarz i Strzelcy.
- `public/style.css` — prezentacja interfejsu.
- `public/script.js` — pobieranie danych przez `fetch()`, renderowanie widoków, obliczanie statystyk i obsługa dodawania/usuwania.

## 3. Backend

`server.js` wykorzystuje Express, CORS, `express.json()` oraz `sqlite3`. Domyślny port to `3000`, z możliwością ustawienia zmiennej środowiskowej `PORT`.

## 4. API

| Metoda | Endpoint | Opis | UI |
|---|---|---|---|
| GET | `/api/players` | Lista zawodników | Tak |
| POST | `/api/players` | Dodanie zawodnika | Tak |
| PUT | `/api/players/:id` | Aktualizacja zawodnika | Nie |
| DELETE | `/api/players/:id` | Usunięcie zawodnika | Tak |
| GET | `/api/matches` | Lista meczów | Tak |
| POST | `/api/matches` | Dodanie meczu | Tak |
| PUT | `/api/matches/:id` | Aktualizacja meczu | Nie |
| DELETE | `/api/matches/:id` | Usunięcie meczu | Tak |

## 5. Baza danych

Tabela `players`: `id`, `name`, `number`, `position`, `goals`, `assists`, `appearances`.

Tabela `matches`: `id`, `opponent`, `match_date`, `match_time`, `location`, `result`.

Tabele nie są połączone kluczami obcymi. Podczas uruchomienia baza i tabele tworzone są automatycznie. Przykładowe rekordy są dodawane, jeśli odpowiednia tabela jest pusta.

## 6. Ograniczenia

Projekt nie zawiera logowania, autoryzacji, edycji z poziomu WWW, historii zmian ani powiązania statystyk z konkretnymi meczami. Nie należy zakładać istnienia tych funkcji.
