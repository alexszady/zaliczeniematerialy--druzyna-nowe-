# Aktorzy systemu

## Użytkownik aplikacji
Osoba korzystająca z interfejsu WWW. Może:
- przeglądać zawodników;
- dodawać i usuwać zawodników;
- przeglądać statystyki Dashboard;
- przeglądać terminarz;
- dodawać i usuwać mecze;
- przeglądać tabelę strzelców.

## Klient REST API
Zewnętrzny program lub narzędzie wysyłające żądania HTTP bezpośrednio do API. Może wywoływać udostępnione endpointy, w tym `PUT /api/players/:id` i `PUT /api/matches/:id`. Projekt nie implementuje uwierzytelniania ani autoryzacji klienta.

## Uwaga o rolach
W kodzie nie istnieją konta ani role „Administrator” i „Trener”. Nie należy przedstawiać ich jako wymuszanych uprawnień systemowych.
