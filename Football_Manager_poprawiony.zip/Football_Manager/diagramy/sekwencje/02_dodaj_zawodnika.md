# Diagram sekwencji — 02 dodaj zawodnika

```mermaid
sequenceDiagram
    actor U as Użytkownik
    participant UI as Interfejs WWW
    participant API as Express API
    participant DB as SQLite
    U->>UI: Wypełnia formularz i klika Zapisz
    UI->>UI: Sprawdza imię, numer i pozycję
    UI->>API: POST /api/players (JSON)
    API->>API: Waliduje wymagane pola
    API->>DB: INSERT INTO players
    DB-->>API: lastID
    API-->>UI: 201 Created + rekord zawodnika
    UI->>API: GET /api/players
    API-->>UI: 200 OK + lista
    UI-->>U: Pokazuje zaktualizowaną listę
```
