# Wyświetl statystyki

- **ID:** PU_05
- **Aktor:** Użytkownik aplikacji
- **Warunki wstępne:** Aplikacja została uruchomiona.

## Scenariusz podstawowy
1. Użytkownik otwiera Dashboard.
2. Interfejs pobiera listę zawodników przez `GET /api/players`.
3. Interfejs pobiera listę meczów przez `GET /api/matches`.
4. JavaScript oblicza liczbę zawodników, sumę goli, sumę asyst i liczbę meczów.
5. Dashboard prezentuje obliczone wartości.

## Scenariusze alternatywne / błędy
Przy pustych tabelach sumy i liczności wynoszą zero. Błąd pobierania danych powoduje komunikat o braku połączenia.

## Warunek końcowy
Podstawowe statystyki drużyny są widoczne na Dashboard.
