# Diagram sekwencji — wyświetlenie tabeli strzelców

```mermaid
sequenceDiagram
    actor U as Użytkownik
    participant UI as Interfejs WWW
    participant API as Express API
    participant DB as SQLite
    U->>UI: Uruchamia aplikację
    UI->>API: GET /api/players
    API->>DB: SELECT * FROM players ORDER BY goals DESC, name ASC
    DB-->>API: Lista zawodników
    API-->>UI: 200 OK + JSON
    U->>UI: Otwiera sekcję Strzelcy
    UI->>UI: Sortuje malejąco według liczby goli
    UI-->>U: Wyświetla tabelę z pobranych danych
```
