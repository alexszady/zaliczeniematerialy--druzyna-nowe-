# Usuń zawodnika

- **ID:** PU_04
- **Aktor:** Użytkownik aplikacji
- **Warunki wstępne:** Zawodnik znajduje się na liście.

## Scenariusz podstawowy
1. Użytkownik klika „Usuń” przy wybranym zawodniku.
2. Interfejs prosi o potwierdzenie.
3. Po potwierdzeniu wysyła `DELETE /api/players/:id`.
4. API usuwa rekord z SQLite.
5. Interfejs ponownie pobiera dane i odświeża widok.

## Scenariusze alternatywne / błędy
Jeśli użytkownik anuluje potwierdzenie, żądanie DELETE nie jest wysyłane.

## Warunek końcowy
Wskazany zawodnik zostaje usunięty z tabeli `players`.
