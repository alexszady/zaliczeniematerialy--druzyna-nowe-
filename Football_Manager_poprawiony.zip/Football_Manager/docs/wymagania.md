# Wymagania systemu Football Manager

Wymagania opracowano na podstawie aktualnej implementacji w `server.js` oraz plikach `public/`.

## Wymagania funkcjonalne

| ID | Wymaganie | Realizacja |
|---|---|---|
| WF-01 | System wyświetla listę zawodników. | `GET /api/players`, tabela w sekcji Zawodnicy |
| WF-02 | System umożliwia dodanie zawodnika z imieniem i nazwiskiem, numerem oraz pozycją. | Formularz WWW i `POST /api/players` |
| WF-03 | System umożliwia usunięcie zawodnika po potwierdzeniu. | `DELETE /api/players/:id` |
| WF-04 | System przechowuje gole, asysty i liczbę występów zawodnika. | Kolumny `goals`, `assists`, `appearances` w `players` |
| WF-05 | System prezentuje liczbę zawodników, goli, asyst i meczów. | Dashboard; sumowanie w `script.js` |
| WF-06 | System prezentuje tabelę strzelców uporządkowaną malejąco według goli. | Sekcja Strzelcy i `renderScorers()` |
| WF-07 | System wyświetla terminarz z przeciwnikiem, datą, godziną, miejscem i wynikiem. | `GET /api/matches` i `renderMatches()` |
| WF-08 | System umożliwia dodanie meczu. | Formularz WWW i `POST /api/matches` |
| WF-09 | System umożliwia usunięcie meczu po potwierdzeniu. | `DELETE /api/matches/:id` |
| WF-10 | API udostępnia aktualizację danych zawodnika. | `PUT /api/players/:id`; brak formularza WWW |
| WF-11 | API udostępnia aktualizację danych meczu. | `PUT /api/matches/:id`; brak formularza WWW |
| WF-12 | System przechowuje dane w SQLite. | Tabele `players` i `matches` |

## Wymagania niefunkcjonalne

- WNF-01: aplikacja działa w przeglądarce internetowej.
- WNF-02: backend udostępnia API HTTP, a dane są przesyłane w formacie JSON.
- WNF-03: aplikacja wykorzystuje Node.js, Express i SQLite3.
- WNF-04: zapytania SQL wykorzystują parametry wiązane.
- WNF-05: interfejs sygnalizuje błąd połączenia podczas początkowego pobierania danych.
- WNF-06: plik bazy danych jest tworzony lokalnie przy uruchomieniu serwera.

## Ograniczenia aktualnej wersji

- Nie ma logowania, rejestracji ani autoryzacji ról.
- Edycja danych istnieje w API, ale nie ma jej w interfejsie WWW.
- Nie ma tabeli łączącej zawodników z konkretnymi meczami.
- Brak zaawansowanej walidacji typów i zakresów wszystkich pól.
