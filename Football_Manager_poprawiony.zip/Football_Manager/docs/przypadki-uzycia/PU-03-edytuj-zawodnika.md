# Aktualizuj zawodnika (API)

- **ID:** PU_03
- **Aktor:** Klient REST API
- **Warunki wstępne:** Rekord zawodnika istnieje; klient zna jego identyfikator.

## Scenariusz podstawowy
1. Klient wysyła `PUT /api/players/:id` z kompletem pól zawodnika w JSON.
2. API wykonuje instrukcję `UPDATE players ... WHERE id = ?`.
3. API zwraca komunikat o aktualizacji.

## Scenariusze alternatywne / błędy
Jeżeli identyfikator nie istnieje, zapytanie nie aktualizuje żadnego rekordu; aktualna implementacja nie zwraca osobnego statusu 404. Operacja nie jest dostępna z poziomu interfejsu WWW.

## Warunek końcowy
Dane rekordu zostają zaktualizowane, jeśli wskazany identyfikator istnieje.
