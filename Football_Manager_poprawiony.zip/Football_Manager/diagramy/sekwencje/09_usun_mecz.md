# Diagram sekwencji — 09 usun mecz

```mermaid
sequenceDiagram
    actor U as Użytkownik
    participant UI as Interfejs WWW
    participant API as Express API
    participant DB as SQLite
    U->>UI: Klika Usuń mecz i potwierdza
    UI->>API: DELETE /api/matches/:id
    API->>DB: DELETE FROM matches WHERE id = ?
    DB-->>API: Status zapytania SQL
    API-->>UI: 200 OK + komunikat
    UI->>API: GET /api/matches
    API-->>UI: Zaktualizowana lista meczów
    UI-->>U: Wyświetla terminarz bez usuniętego meczu
```
