# Diagram sekwencji — 07 dodaj mecz

```mermaid
sequenceDiagram
    actor U as Użytkownik
    participant UI as Interfejs WWW
    participant API as Express API
    participant DB as SQLite
    U->>UI: Wypełnia formularz i klika Zapisz
    UI->>UI: Sprawdza przeciwnika i datę
    UI->>API: POST /api/matches (JSON)
    API->>API: Waliduje przeciwnika i datę
    API->>DB: INSERT INTO matches
    DB-->>API: lastID
    API-->>UI: 201 Created + id
    UI->>API: GET /api/matches
    API-->>UI: 200 OK + lista
    UI-->>U: Wyświetla zaktualizowany terminarz
```
