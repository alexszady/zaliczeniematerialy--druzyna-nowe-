# Aktualizuj mecz (API)

- **ID:** PU_09
- **Aktor:** Klient REST API
- **Warunki wstępne:** Rekord meczu istnieje; klient zna jego identyfikator.

## Scenariusz podstawowy
1. Klient wysyła `PUT /api/matches/:id` z danymi meczu w JSON.
2. API wykonuje instrukcję `UPDATE matches ... WHERE id = ?`.
3. API zwraca komunikat o aktualizacji.

## Scenariusze alternatywne / błędy
Jeżeli identyfikator nie istnieje, żaden rekord nie zostaje zmieniony; aktualna implementacja nie zwraca osobnego statusu 404. Operacja nie jest dostępna z poziomu interfejsu WWW.

## Warunek końcowy
Dane meczu zostają zaktualizowane, jeśli wskazany identyfikator istnieje.
