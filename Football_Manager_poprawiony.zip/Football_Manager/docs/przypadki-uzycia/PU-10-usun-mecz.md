# Usuń mecz

- **ID:** PU_10
- **Aktor:** Użytkownik aplikacji
- **Warunki wstępne:** Mecz znajduje się w terminarzu.

## Scenariusz podstawowy
1. Użytkownik klika „Usuń mecz” przy wybranym spotkaniu.
2. Interfejs prosi o potwierdzenie.
3. Po potwierdzeniu wysyła `DELETE /api/matches/:id`.
4. API usuwa rekord z SQLite.
5. Interfejs ponownie pobiera terminarz i odświeża widok.

## Scenariusze alternatywne / błędy
Jeśli użytkownik anuluje potwierdzenie, żądanie DELETE nie jest wysyłane.

## Warunek końcowy
Wskazany mecz zostaje usunięty z tabeli `matches`.
