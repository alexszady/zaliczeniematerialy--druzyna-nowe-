# Diagram sekwencji — wyświetlenie zawodników

```mermaid
sequenceDiagram
    actor U as Użytkownik
    participant UI as Interfejs WWW
    participant API as Express API
    participant DB as SQLite
    U->>UI: Uruchamia aplikację
    UI->>API: GET /api/players
    API->>DB: SELECT * FROM players ORDER BY goals DESC, name ASC
    DB-->>API: Lista zawodników
    API-->>UI: 200 OK + JSON
    UI->>API: GET /api/matches
    API->>DB: SELECT * FROM matches ORDER BY match_date ASC
    DB-->>API: Lista meczów
    API-->>UI: 200 OK + JSON
    UI-->>U: Renderuje widoki i dane zawodników
    U->>UI: Otwiera sekcję Zawodnicy
    UI-->>U: Pokazuje tabelę z pobranych danych
```
