# Opis diagramów

## 1. Przypadki użycia
Diagram podstawowy przedstawia osiem funkcji dostępnych w interfejsie WWW. Diagram rozszerzony dodatkowo pokazuje endpointy aktualizacji zawodnika i meczu, które są dostępne wyłącznie przez REST API.

## 2. ERD
ERD odzwierciedla dokładnie dwie tabele tworzone w `server.js`: `players` i `matches`. Każda tabela ma własny klucz główny `id`. W kodzie nie ma kluczy obcych ani relacji między tymi tabelami.

## 3. Diagram struktury / modułów
Zamiast fikcyjnych klas domenowych diagram przedstawia rzeczywiste moduły aplikacji: `index.html`, `script.js`, `style.css`, `server.js` oraz bazę SQLite. Projekt jest aplikacją proceduralną opartą na funkcjach JavaScript, a nie implementacją obiektowego modelu klas.

## 4. Diagramy aktywności
Każdy przypadek użycia ma osobny diagram aktywności. Diagramy aktualizacji opisują wyłącznie wywołanie endpointów PUT przez klienta REST API, ponieważ interfejs WWW nie udostępnia edycji.

## 5. Diagramy sekwencji
Każdy diagram sekwencji pokazuje ścieżkę poprawnego wykonania danego przypadku użycia, zgodnie z wytycznymi do projektu. Diagramy są zapisane w Mermaid w katalogu `diagramy/sekwencje/` i są renderowane bezpośrednio przez GitHub.

## Ważne ograniczenia wynikające z kodu
- Brak logowania i autoryzacji.
- Brak formularzy edycji w interfejsie WWW; endpointy PUT istnieją w API.
- Brak relacji między `players` i `matches`.
- Statystyki Dashboard są sumowane po stronie przeglądarki na podstawie pobranych rekordów.
- Dane przykładowe są dodawane podczas pierwszego uruchomienia, jeśli odpowiednia tabela jest pusta.
