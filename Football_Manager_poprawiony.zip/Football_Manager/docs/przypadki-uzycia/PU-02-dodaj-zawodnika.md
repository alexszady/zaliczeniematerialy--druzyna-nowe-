# Dodaj zawodnika

- **ID:** PU_02
- **Aktor:** Użytkownik aplikacji
- **Warunki wstępne:** Użytkownik otworzył sekcję „Zawodnicy”.

## Scenariusz podstawowy
1. Użytkownik otwiera formularz dodawania.
2. Wprowadza imię i nazwisko, numer, pozycję oraz statystyki (opcjonalnie pozostawia wartości domyślne).
3. Interfejs sprawdza, czy podano imię, numer i pozycję.
4. Interfejs wysyła `POST /api/players` z danymi JSON.
5. API sprawdza wymagane pola i zapisuje rekord w SQLite.
6. Interfejs odświeża dane i pokazuje nowego zawodnika.

## Scenariusze alternatywne / błędy
Brak imienia, numeru lub pozycji powoduje komunikat walidacyjny po stronie interfejsu. API zwraca HTTP 400, jeśli brakuje wymaganych danych.

## Warunek końcowy
Nowy zawodnik zostaje zapisany w tabeli `players` i pojawia się na liście.
