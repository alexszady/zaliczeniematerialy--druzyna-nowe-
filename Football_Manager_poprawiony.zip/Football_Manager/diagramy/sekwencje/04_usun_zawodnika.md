# Diagram sekwencji — 04 usun zawodnika

```mermaid
sequenceDiagram
    actor U as Użytkownik
    participant UI as Interfejs WWW
    participant API as Express API
    participant DB as SQLite
    U->>UI: Klika Usuń i potwierdza
    UI->>API: DELETE /api/players/:id
    API->>DB: DELETE FROM players WHERE id = ?
    DB-->>API: Status zapytania SQL
    API-->>UI: 200 OK + komunikat
    UI->>API: GET /api/players
    API-->>UI: Zaktualizowana lista
    UI-->>U: Wyświetla listę bez usuniętego zawodnika
```
