# Wyświetl tabelę strzelców

- **ID:** PU_07
- **Aktor:** Użytkownik aplikacji
- **Warunki wstępne:** Dostępne są dane zawodników.

## Scenariusz podstawowy
1. Użytkownik wybiera sekcję „Strzelcy”.
2. Interfejs wykorzystuje pobraną listę zawodników (`GET /api/players`).
3. Funkcja `renderScorers()` sortuje zawodników malejąco według liczby goli.
4. Interfejs wyświetla pozycję w rankingu, nazwisko, pozycję, występy, asysty i gole.

## Scenariusze alternatywne / błędy
Przy braku zawodników tabela nie zawiera pozycji rankingowych.

## Warunek końcowy
Tabela strzelców zostaje wyświetlona.
