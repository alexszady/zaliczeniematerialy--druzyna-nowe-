# Diagram sekwencji — wyświetlenie terminarza

```mermaid
sequenceDiagram
    actor U as Użytkownik
    participant UI as Interfejs WWW
    participant API as Express API
    participant DB as SQLite
    U->>UI: Uruchamia aplikację
    UI->>API: GET /api/matches
    API->>DB: SELECT * FROM matches ORDER BY match_date ASC
    DB-->>API: Lista meczów
    API-->>UI: 200 OK + JSON
    U->>UI: Otwiera Terminarz
    UI-->>U: Wyświetla terminarz z pobranych danych
```
