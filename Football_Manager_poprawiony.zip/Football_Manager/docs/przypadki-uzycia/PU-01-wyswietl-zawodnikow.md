# Wyświetl zawodników

- **ID:** PU_01
- **Aktor:** Użytkownik aplikacji
- **Warunki wstępne:** Otwarta aplikacja; tabela `players` może zawierać zero lub więcej rekordów.

## Scenariusz podstawowy
1. Użytkownik wybiera sekcję „Zawodnicy”.
2. Interfejs wysyła `GET /api/players`.
3. API pobiera rekordy z SQLite, sortując je według goli malejąco, a następnie nazwy.
4. Interfejs wyświetla tabelę zawodników.

## Scenariusze alternatywne / błędy
Jeżeli API zwróci błąd, interfejs nie może poprawnie załadować danych; przy początkowym ładowaniu wyświetlany jest komunikat o braku połączenia.

## Warunek końcowy
Lista zawodników zostaje wyświetlona.
