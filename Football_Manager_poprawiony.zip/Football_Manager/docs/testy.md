# Plan testów systemu Football Manager

Testy poniżej są planem do ręcznego wykonania. Nie oznaczono ich jako zaliczone, ponieważ wynik musi pochodzić z faktycznego uruchomienia aplikacji.

| ID | Czynność | Oczekiwany rezultat |
|---|---|---|
| T01 | Uruchom `npm install` i `npm start` | Serwer uruchamia się na porcie 3000 lub wskazanym przez `PORT` |
| T02 | Otwórz `http://localhost:3000` | Wyświetla się Dashboard |
| T03 | Otwórz Zawodników | Wyświetla się lista z API |
| T04 | Dodaj zawodnika z kompletem wymaganych danych | Zawodnik pojawia się na liście |
| T05 | Spróbuj dodać zawodnika bez imienia/numeru/pozycji | Interfejs pokazuje komunikat i nie wysyła formularza |
| T06 | Usuń zawodnika i potwierdź | Zawodnik znika z listy |
| T07 | Usuń zawodnika i anuluj potwierdzenie | Rekord pozostaje na liście |
| T08 | Otwórz Dashboard | Liczby zawodników, goli, asyst i meczów odpowiadają danym |
| T09 | Otwórz Terminarz | Mecze są posortowane rosnąco po dacie |
| T10 | Dodaj mecz z przeciwnikiem i datą | Mecz pojawia się w terminarzu |
| T11 | Spróbuj dodać mecz bez przeciwnika lub daty | Interfejs pokazuje komunikat |
| T12 | Usuń mecz i potwierdź | Mecz znika z terminarza |
| T13 | Otwórz Strzelców | Zawodnicy są uporządkowani malejąco według goli |
| T14 | Wywołaj `PUT /api/players/:id` narzędziem REST | API aktualizuje wskazany rekord; brak formularza WWW |
| T15 | Wywołaj `PUT /api/matches/:id` narzędziem REST | API aktualizuje wskazany rekord; brak formularza WWW |

## Protokół wykonania

Dla każdego testu należy uzupełnić datę, wynik (PASS/FAIL) i uwagi po jego rzeczywistym wykonaniu. Tabela jest planem testów, nie raportem z wykonanych testów.
